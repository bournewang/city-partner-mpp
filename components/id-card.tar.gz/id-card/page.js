import userApi from "../../api/user"
Component({
  data: {
    frontList: [],
    endList: []
  },
  onLoad() {
    
  },
  methods:{
    handleAdd(e) {
      console.log("handle add: "+e.currentTarget.dataset['type'])
      const type = e.currentTarget.dataset['type']
      const { frontList, endList } = this.data;
      const { files } = e.detail;
      console.log(e.detail)
  
      // 方法1：选择完所有图片之后，统一上传，因此选择完就直接展示
      if (type == 'front') {
        this.setData({frontList: [...frontList, ...files]});
      }else{
        this.setData({endList: [...endList, ...files]});
      }
      // 方法2：每次选择图片都上传，展示每次上传图片的进度
      // files.forEach(file => this.onUpload(file))
      const file = files[0]
      this.onUpload(file, type)
    },
    onUpload(file, type) {
      const { frontList, endList } = this.data;
      var filelist = type == 'front' ? frontList : endList;
      var listName = type == 'front' ? 'frontList' : 'endList';
      if (type == 'front'){
        this.setData({frontList: [...frontList, { ...file, status: 'loading' }]});
      }else{
        this.setData({endList: [...endList, { ...file, status: 'loading' }]});
      }
  
      const { length } = filelist;
      const task = userApi.uploadIdCard(file.url, type) 
      // fileApi.upload(file.url, {collection: 'id_card_'+type})
      task.onProgressUpdate((res) => {
        this.setData({
          [`${listName}[${length}].percent`]: res.progress,
        });
        console.log("progress: "+res.progress)
        if (res.progress == 100) {
          this.setData({
            [`${listName}[${length}].status`]: 'done',
          });
        }
      });
    },
    handleRemove(e) {
      const { index } = e.detail;
      const { frontList } = this.data;
  
      frontList.splice(index, 1);
      this.setData({
        frontList,
      });
    } 
  }

})
